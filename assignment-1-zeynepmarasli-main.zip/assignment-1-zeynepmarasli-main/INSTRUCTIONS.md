# Assignment #1
The purpose of this assignment is to familiarize you with regular expressions and prepare you for other NLP/CL tasks later this semester.

Steps to this assignment are as follows:
  * Read the Assignment1.pdf file thoroughly
  * Prepare your input file (if not using input.Hw1.docx)
  * Modify the .ipynb file in this repository with your code to fulfill the assignment requirements. 
  * Use Git to add and commit your changes
  * Use Git to push your changes to GitHub
  
Do let us know on Canvas if you have questions.
