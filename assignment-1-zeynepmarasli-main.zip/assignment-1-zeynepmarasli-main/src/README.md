# Indicate the name of the program
# Give a short description of the problem solved
# Give a short description on how to run your code
#Name of program: assignment-1.ipynb
    #this program implements a named entity recognizer for dates(fixed and formal) using regular expressions & outputs the identified expressions in an output file (output.txt) 


#to run this code:
    This program takes input from two files: the input text (input.txt) and a file containing federal holidays (federal_holidays.txt). In order for this code to run, the user will need to change the file paths for these folders for their own computers. It is currently set to my computer: 
                    input_file = open("/Users/zeynepmarasli/assignment-1-zeynepmarasli/src/Data/Input/input.txt", "r")
                    
    #This program also writes the matched regular expressions to an output file, output.txt. In order for this to run, the user must also change the directory of this file. Currently it is set to my computer similar to the above example. 
                    
             